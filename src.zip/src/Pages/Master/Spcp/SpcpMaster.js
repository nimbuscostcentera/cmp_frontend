// StoneRateMaster.jsx (edited)
import React, { useEffect, useMemo, useRef, useState } from "react";
import { toast, ToastContainer } from "react-toastify";
import { Container, Row, Col, Button } from "react-bootstrap";
import "../../../Components/Table/table.css";
import useSpcpMaster from "../../../Store/MasterStore/useSpcpMaster";
import StoneDetailsModal from "./StoneDetailsModal";
import useLayout2Master from "../../../Store/MasterStore/useLayout2Master";
import useLayout8Master from "../../../Store/MasterStore/useLayout8Master";
import useLayout1Master from "../../../Store/MasterStore/useLayout1Master";
import SearchableDropDown from "../../../Components/SearchableDropDown";
import SpcpMasterTable from "./SpcpMasterTable";

import MasterDropdownMenu from "../../../Components/Dropdown/MasterDropdown"; // <- new
import { masters } from "../MasterLayouts/MasterInitialData"; // adjust path if needed

function StoneRateMaster() {
  const inputRef = useRef();
  const [searchData, setSearchData] = useState("");
  const [isDisable, setIsDisable] = useState(false);
  const [textDetail, setTextDetail] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [colorList, setColorList] = useState([]);
  const [mischargeList, setMischargeList] = useState([]);

  const [stoneRateHeaders, setStoneRateHeaders] = useState({
    type: "header",
    ID_StoneM: null,
    Srl_Col: 1,
    ID_StoneS: null,
    ID_Color: null,
    Pcs: "",
    Weight: "",
    CP: "",
    SP: "",
    totalcharge: "",
    Tolerance_Upper: "",
    Tolerance_Lower: "",
    Details: [],
  });

  const { addIsLoading, addError, addIsSuccess, addSpcp, clearAddState } =
    useSpcpMaster();

  const { layout2, fetchLayout2 } = useLayout2Master(); // Stone Master
  const { layout8, fetchLayout8 } = useLayout8Master(); // Stone Sub Master
  const { fetchLayout1 } = useLayout1Master(); // Color

  const dropdownListStoneS = useMemo(
    () =>
      layout8.map((item) => ({
        label: `${item.Sub_Code}`,
        value: item.Sub_ID,
        Standard_Weight: item.Weight,
      })),
    [layout8]
  );

  const dropdownListStoneM = useMemo(
    () =>
      layout2.map((item) => ({
        label: `${item.Code}`,
        value: item.ID,
      })),
    [layout2]
  );

  const dropdownListColor = useMemo(
    () =>
      colorList.map((item) => ({
        label: `${item.Code}`,
        value: item.ID,
      })),
    [colorList]
  );
  const dropdownListMiscCharge = useMemo(
    () =>
      mischargeList.map((item) => ({
        label: `${item.Code}: ${item.Description}`,
        value: item.ID,
      })),
    [mischargeList]
  );

  useEffect(() => {
    inputRef.current?.focus();
    fetchLayout8("ssm");
    fetchLayout2("sm");

    async function fetchLayout() {
      const res = await fetchLayout1("cm");
      setColorList(res);
      const res1 = await fetchLayout1("mm");
      setMischargeList(res1);
    }
    fetchLayout();
  }, []);

  // Handle input changes
  const OnChangeHandler = (e) => {
    const { name, value } = e.target;
    if (name === "CP") {
      const regex = /^\d{0,7}(\.\d{0,2})?$/;
      if (value !== "" && !regex.test(value)) return;
    }

    if (name === "Tolerance_Lower" || name === "Tolerance_Upper") {
      const regex = /^[0-9]{0,6}$/;
      if (value !== "" && !regex.test(value)) return;
    }
    setStoneRateHeaders((prev) => ({ ...prev, [name]: value }));
  };

  // Calculate SP = CP + Σ(Misc Charges)
  useEffect(() => {
    const cp = parseFloat(stoneRateHeaders.CP || 0);
    const miscTotal = stoneRateHeaders.Details.reduce(
      (acc, row) => acc + parseFloat(row.Amount || 0),
      0
    );
    const sp = cp + miscTotal;
    setStoneRateHeaders((prev) => ({
      ...prev,
      SP: sp.toFixed(2),
      totalcharge: miscTotal.toFixed(2),
    }));
  }, [stoneRateHeaders.CP, stoneRateHeaders.Details]);

  const SaveData = () => {
    const { ID_StoneM, Srl_Col, ID_StoneS, ID_Color } = stoneRateHeaders;
    if (
      !ID_StoneM ||
      !Srl_Col ||
      !ID_StoneS ||
      !ID_Color ||
      stoneRateHeaders.Tolerance_Lower === "" ||
      stoneRateHeaders.Tolerance_Upper === ""
    ) {
      toast.error("Missing required fields!");
      return;
    }
    const tolLower = Number(stoneRateHeaders.Tolerance_Lower);
    const tolUpper = Number(stoneRateHeaders.Tolerance_Upper);

    console.log(tolLower, tolUpper, "Tol");

    if (!isNaN(tolLower) && !isNaN(tolUpper)) {
      if (tolLower >= tolUpper) {
        toast.error(
          "Tolerance Lower cannot be greater than or equal to Tolerance Upper"
        );
        return;
      }

      if (tolLower < 0 || tolUpper < 0) {
        toast.error("Tolerance values cannot be negative");
        return;
      }
    }

    if (!stoneRateHeaders.Details || stoneRateHeaders.Details.length === 0) {
      toast.error("Please add at least one Misc. Charge in details.");
      return;
    }
    addSpcp("header", stoneRateHeaders);
  };

  useEffect(() => {
    if (addIsSuccess && !addIsLoading && !addError) {
      toast.success("Stone Rate Setting Added Successfully");
      setStoneRateHeaders({
        type: "header",
        ID_StoneM: null,
        Srl_Col: 1,
        ID_StoneS: null,
        ID_Color: null,
        Pcs: "",
        Weight: "",
        CP: "",
        SP: "",
        totalcharge: "",
        Tolerance_Upper: "",
        Tolerance_Lower: "",
        Details: [],
      });
    }
    if (addError && !addIsLoading && !addIsSuccess) {
      toast.error(addError);
    }
    clearAddState();
  }, [addIsLoading, addIsSuccess, addError]);

  const handleSaveDetails = (rows) => {
    setStoneRateHeaders((prev) => ({ ...prev, Details: rows }));
  };

  return (
    <Container fluid className="p-0" style={{ width: "98%" }}>
      <ToastContainer />
      <Row className="w-100">
        <Col
          xs={12}
          className="d-flex justify-content-center align-items-center my-2"
        >
          <div className="flex items-center gap-2">
            <label className="mr-2 text-sm font-semibold">Select Master:</label>

            {/* Master dropdown — consistent UI across all masters */}
            <MasterDropdownMenu
              masters={masters}
              layoutMasterRoute="/auth/layout"
            />
          </div>
        </Col>

        {/* rest of your JSX remains unchanged */}
        <Col xs={12}>
          <div
            className="table-wrapper"
            style={{ overflowX: "auto", marginBottom: "10px" }}
          >
            <table className="text-sm">
              <thead className="tab-head">
                <tr>
                  <th className="w-[30px]">
                    <i className="bi bi-tag text-xs md:text-sm"></i>
                  </th>
                  <th>Stone Master*</th>
                  <th>Stone Sub*</th>
                  <th>Color*</th>
                  <th>Pcs*</th>
                  <th>Weight*</th>
                  <th>CP*</th>
                  <th>Tol Lower*</th>
                  <th>Tol Upper*</th>
                  <th style={{ width: "400px" }}>Mis. C.*</th>
                  <th>SP* (Auto)</th>
                </tr>
              </thead>
              <tbody className="tab-body">
                <tr>
                  <td>
                    <i className="bi bi-caret-right-fill text-xs md:text-sm"></i>
                  </td>
                  <td>
                    <SearchableDropDown
                      options={dropdownListStoneM}
                      handleChange={(e) => {
                        const id = e.target.value;
                        setStoneRateHeaders((prev) => ({
                          ...prev,
                          ID_StoneM: id,
                        }));
                      }}
                      selectedVal={stoneRateHeaders.ID_StoneM || -1}
                      label={"ID_StoneM"}
                      placeholder={"--Select Stone M--"}
                      width={"100%"}
                      defaultval={-1}
                    />
                  </td>

                  <td>
                    <SearchableDropDown
                      options={dropdownListStoneS}
                      handleChange={(e) => {
                        const id = e.target.value;
                        const stone_weight = layout8.find(
                          (stone) => stone.Sub_ID === id
                        )?.Weight;
                        setStoneRateHeaders((prev) => ({
                          ...prev,
                          Weight: stone_weight,
                          ID_StoneS: e.target.value,
                        }));
                      }}
                      selectedVal={stoneRateHeaders.ID_StoneS || -1}
                      label={"ID_StoneS"}
                      placeholder={"--Select Stone Sub M--"}
                      width={"100%"}
                      defaultval={-1}
                    />
                  </td>

                  <td>
                    <SearchableDropDown
                      options={dropdownListColor}
                      handleChange={(e) =>
                        setStoneRateHeaders((prev) => ({
                          ...prev,
                          ID_Color: e.target.value,
                        }))
                      }
                      selectedVal={stoneRateHeaders.ID_Color || -1}
                      label={"ID_Color"}
                      placeholder={"--Select Color--"}
                      width={"100%"}
                      defaultval={-1}
                    />
                  </td>

                  <td>
                    <input
                      placeholder="Pcs"
                      className="input-cell text-xs md:text-sm py-1"
                      name="Pcs"
                      value={stoneRateHeaders.Pcs}
                      onChange={OnChangeHandler}
                      style={{ width: "70px" }}
                    />
                  </td>
                  <td>
                    <input
                      placeholder="Weight"
                      className="input-cell text-xs md:text-sm py-1"
                      name="Weight"
                      value={stoneRateHeaders.Weight}
                      onChange={OnChangeHandler}
                      readOnly
                      style={{ width: "100px", background: "#f3f3f3" }}
                    />
                  </td>

                  <td>
                    <input
                      placeholder="CP"
                      className="input-cell text-xs md:text-sm py-1"
                      name="CP"
                      value={stoneRateHeaders.CP}
                      onChange={OnChangeHandler}
                      style={{ width: "100px" }}
                    />
                  </td>
                  <td>
                    <input
                      name="Tolerance_Lower"
                      type="number"
                      value={stoneRateHeaders.Tolerance_Lower}
                      onChange={OnChangeHandler}
                      placeholder="Tol Lower"
                      className="input-cell text-xs md:text-sm py-1"
                    />
                  </td>
                  <td>
                    <input
                      name="Tolerance_Upper"
                      type="number"
                      value={stoneRateHeaders.Tolerance_Upper}
                      onChange={OnChangeHandler}
                      placeholder="Tol Upper"
                      className="input-cell text-xs md:text-sm py-1"
                    />
                  </td>
                  <td>
                    <div className="d-flex align-items-center fl">
                      <input
                        placeholder="Principal Amount"
                        className="input-cell"
                        name="principalAmount"
                        value={stoneRateHeaders.totalcharge}
                        type="number"
                        step="0.01"
                        readOnly
                      />
                      <Button
                        variant="secondary"
                        size="sm"
                        onClick={() => setShowModal(true)}
                      >
                        <i
                          className="bi bi-pencil-square"
                          style={{ fontSize: "12px" }}
                        ></i>
                      </Button>
                    </div>
                  </td>
                  <td>
                    <input
                      placeholder="SP"
                      className="input-cell text-xs md:text-sm py-1"
                      name="SP"
                      value={stoneRateHeaders.SP}
                      readOnly
                      style={{ width: "100px", background: "#f3f3f3" }}
                    />
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </Col>

        <Col
          xs={12}
          className="d-flex justify-content-between align-items-center mb-2"
        >
          <Button
            variant="success"
            onClick={SaveData}
            disabled={isDisable}
            size="sm"
          >
            {addIsLoading ? "Please wait..." : "Submit"}
          </Button>

          <div className="flex-grow" style={{ maxWidth: "250px" }}>
            <div className="d-flex align-items-center border border-blue-400 rounded-md p-1 text-xs md:text-sm">
              <i className="bi bi-search text-gray-400 mx-1"></i>
              <input
                value={searchData}
                type="search"
                placeholder="Search here..."
                onChange={(e) => setSearchData(e.target.value)}
                className="w-100 border-0 outline-none bg-transparent px-1"
              />
            </div>
          </div>
        </Col>

        <Col xs={12}>
          <SpcpMasterTable
            isDisable={isDisable}
            setIsDisable={setIsDisable}
            search={searchData}
            setTextDetail={setTextDetail}
            type={"header"}
            dropdownListStoneS={dropdownListStoneS}
            dropdownListStoneM={dropdownListStoneM}
            dropdownListColor={dropdownListColor}
            dropdownListMiscCharge={dropdownListMiscCharge}
          />
        </Col>
      </Row>

      {showModal && (
        <StoneDetailsModal
          show={showModal}
          handleClose={() => setShowModal(false)}
          totalcharge={stoneRateHeaders.totalcharge}
          rows={stoneRateHeaders.Details}
          setRows={handleSaveDetails}
          mischargelist={mischargeList}
        />
      )}
    </Container>
  );
}

export default StoneRateMaster;
