import React, { useRef } from "react";
import { toast } from "react-toastify";
import ReusableModal from "../../Components/ReusableModal";
import EstimateTable from "../../Components/EstimateTable";

function DesignDetailsModel({
  show,
  handleClose,
  rows,
  setRows,
  stoneMOptions,
  stoneSOptions,
  sizeOptions,
}) {
  const srlColInputRef = useRef();

  // ➕ Add new row
  const addRow = () => {
    const newRowId = rows.length + 1;
    setRows([
      ...rows,
      {
        rowid: newRowId,
        Srl_Col: newRowId,
        ID_StoneM: null, // ID of Stone Master
        ID_StoneS: null, // ID of Stone Sub
        ID_Size: null, // ID of Size
        Pcs: 0,
        Weight: 0,
      },
    ]);
  };

  // ❌ Delete row
  const deleteRow = (rowid) => {
    setRows(rows.filter((r) => r.rowid !== rowid));
  };

  // Handle cell changes
  const handleDetailModalChange = (rowIndex, colKey, e) => {
    let value = e?.target ? e.target.value : e;
    const updatedRows = [...rows];
    const obj = { ...updatedRows[rowIndex] };

    // When Stone Sub is selected → auto set Weight from options
    if (colKey === "ID_StoneS") {
      obj[colKey] = value;
      const selectedSub = stoneSOptions.find((s) => s.value === value);
      if (selectedSub) {
        obj.Weight = selectedSub.Weight; // assuming stoneSOptions has Weight field
      }
      updatedRows[rowIndex] = obj;
      setRows(updatedRows);
      return;
    }

    // Validation
    if (colKey === "Pcs") {
      const regex = /^[0-9]{0,6}$/;
      if (value !== "" && !regex.test(value)) return;
    }
    if (colKey === "Weight") {
      const regex = /^\d{0,6}(\.\d{0,3})?$/; // 6.3 format
      if (value !== "" && !regex.test(value)) return;
    }

    obj[colKey] = value;
    updatedRows[rowIndex] = obj;
    setRows(updatedRows);
  };

  // ✅ Save rows back to parent
  const saveItem = () => {
    handleClose();
  };

  // 🔹 Table columns
  const detailColumns = [
    {
      label: "Stone Master",
      key: "ID_StoneM",
      AutoSearch: true,
      SearchLabel: "label",
      SearchValue: "value",
      PlaceHolder: "Select Stone Master",
      data: stoneMOptions,
      width: "200px",
    },
    {
      label: "Stone Sub",
      key: "ID_StoneS",
      AutoSearch: true,
      SearchLabel: "label",
      SearchValue: "value",
      PlaceHolder: "Select Stone Sub",
      data: stoneSOptions,
      width: "200px",
    },
    {
      label: "Size",
      key: "ID_Size",
      AutoSearch: true,
      SearchLabel: "label",
      SearchValue: "value",
      PlaceHolder: "Select Size",
      data: sizeOptions,
      width: "150px",
    },
    {
      label: "Pcs",
      key: "Pcs",
      type: "number",
      width: "100px",
    },
    {
      label: "Weight",
      key: "Weight",
      type: "number",
      width: "120px",
      readonly: true,
    },
  ];

  return (
    <ReusableModal
      isFullScreen
      show={show}
      Title="Stone Details"
      isPrimary
      isSuccess
      handleClose={handleClose}
      handlePrimary={saveItem}
      handleSuccess={addRow}
      SuccessButtonName="Add Row"
      PrimaryButtonName="Save"
      body={
        <EstimateTable
          columns={detailColumns}
          rows={rows}
          handleChange={handleDetailModalChange}
          deleteRow={deleteRow}
          isDelete
          id="rowid"
          toaster={toast}
          priorityref={srlColInputRef}
          tableWidth="100%"
        />
      }
    />
  );
}

export default DesignDetailsModel;
