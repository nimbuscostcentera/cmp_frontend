import React, { useEffect, useMemo, useRef, useState } from "react";
import { toast, ToastContainer } from "react-toastify";
import { Container, Row, Col, Button } from "react-bootstrap";
import "../../Components/Table/table.css";
import useDesignMaster from "../../Store/MasterStore/useDesignMaster";
import Layout13Table from "../Layout13/Layout13Table";
import useLayout2Master from "../../Store/MasterStore/useLayout2Master";
import useLayout10Master from "../../Store/MasterStore/useLayout10Master";
import useLayout1Master from "../../Store/MasterStore/useLayout1Master";
import SearchableDropDown from "../../Components/SearchableDropDown";
import DesignDetailsModel from "./DesignDetailsModel";

function DesignMaster() {
  const inputRef = useRef();
  const [searchData, setSearchData] = useState("");
  const [isDisable, setIsDisable] = useState(false);
  const [textDetail, setTextDetail] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [layoutItem, setLayoutItem] = useState([]);
  const [layoutdgm, setLayoutdgm] = useState([]);
  const [previewImage, setPreviewImage] = useState(null);
  const [fileObj, setFileObj] = useState(null);

  // ✅ Zustand store
  const { addIsLoading, addError, addIsSuccess, addDesign, clearAddState } =
    useDesignMaster();

  // Masters for dropdowns
  const { layout2, fetchLayout2 } = useLayout2Master(); // Stone Master
  const { layout10, fetchLayout10 } = useLayout10Master(); // Stone Sub Master
  const { layout1, fetchLayout1 } = useLayout1Master(); // Size Master

  const [designHeader, setDesignHeader] = useState({
    Design_Code: "",
    Ref_Code: "",
    Design_Description: "",
    Design_Group: "",
    ID_master: "",
    Picture: "",
    Gross_Weight: "",
    Tolerance_Lower: "",
    Tolerance_Upper: "",
    Details: [],
  });

  // Dropdown Data
  const dropdownListStoneM = useMemo(
    () => layout2.map((item) => ({ label: item.Code, value: item.ID })),
    [layout2]
  );

  const dropdownListStoneS = useMemo(
    () =>
      layout10.map((item) => ({
        label: item.Sub_Code,
        value: item.Sub_ID,
        Weight: item.Weight,
      })),
    [layout10]
  );

  const dropdownListSize = useMemo(
    () => layout1.map((item) => ({ label: item.Code, value: item.ID })),
    [layout1]
  );

  const dropdownitem = useMemo(
    () => layoutItem.map((item) => ({ label: item.Code, value: item.ID })),
    [layoutItem]
  );

  const dropdowndgm = useMemo(
    () => layoutdgm.map((item) => ({ label: item.Code, value: item.ID })),
    [layoutdgm]
  );

  useEffect(() => {
    inputRef.current?.focus();
    fetchLayout2("sm");
    fetchLayout10("ssm");

    async function fetchLayout() {
      const res = await fetchLayout1("im");
      setLayoutItem(res);
      const res1 = await fetchLayout1("dgm");
      setLayoutdgm(res1);
    }
    fetchLayout();
  }, []);

  // Handle input change
  const OnChangeHandler = (e) => {
    const { name, value } = e.target;
    if (name === "Gross_Weight") {
      const regex = /^\d{0,6}(\.\d{0,3})?$/;
      if (value !== "" && !regex.test(value)) return;
    }
    setDesignHeader((prev) => ({ ...prev, [name]: value }));
  };

  // Image Upload
  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setFileObj(file);
    const reader = new FileReader();
    reader.onloadend = () => setPreviewImage(reader.result);
    reader.readAsDataURL(file);
  };

  // ✅ Save Data
  const SaveData = async () => {
    const {
      Design_Code,
      Design_Description,
      Design_Group,
      ID_master,
      Gross_Weight,
    } = designHeader;

    if (
      !Design_Code ||
      !Design_Description ||
      !Design_Group ||
      !ID_master ||
      !Gross_Weight
    ) {
      toast.error("All mandatory fields must be filled");
      return;
    }

    const formData = new FormData();
    formData.append("Design_Code", designHeader.Design_Code);
    formData.append("Design_Description", designHeader.Design_Description);
    formData.append("Design_Group", designHeader.Design_Group);
    formData.append("ID_master", designHeader.ID_master);
    formData.append("Gross_Weight", designHeader.Gross_Weight);
    formData.append("Tolerance_Lower", designHeader.Tolerance_Lower || "");
    formData.append("Tolerance_Upper", designHeader.Tolerance_Upper || "");

    // ✅ Important: send Design Details as stringified JSON
    const detailsForBackend = designHeader.Details.map((detail) => ({
      Srl_Col: detail.Srl_Col,
      ID_StoneM: detail.ID_StoneM,
      ID_StoneS: detail.ID_StoneS,
      ID_Size: detail.ID_Size,
      Pcs: detail.Pcs,
      Weight: detail.Weight,
    }));

    formData.append("Details", JSON.stringify(detailsForBackend));

    if (fileObj) formData.append("Picture", fileObj);

    await addDesign("header", formData); // ✅ use Zustand addDesign
  };

  // ✅ After Save success or error
  useEffect(() => {
    if (addIsSuccess && !addIsLoading && !addError) {
      toast.success("Design Master Added Successfully");
      setDesignHeader({
        Design_Code: "",
        Ref_Code: "",
        Design_Description: "",
        Design_Group: "",
        ID_master: "",
        Picture: "",
        Gross_Weight: "",
        Tolerance_Lower: "",
        Tolerance_Upper: "",
        Details: [],
      });
      setPreviewImage(null);
      setFileObj(null);
    }
    if (addError) toast.error(addError);
    clearAddState();
  }, [addIsSuccess, addError]);

  const handleSaveDetails = (rows) => {
    setDesignHeader((prev) => ({ ...prev, Details: rows }));
  };

  return (
    <Container fluid className="p-0" style={{ width: "98%" }}>
      <ToastContainer />
      <Row className="w-100">
        <Col xs={12}>
          <h5 className="mb-0 text-sm md:text-base">Design Master</h5>
          <hr className="my-1" />
        </Col>

        <Col xs={12}>
          <div
            className="table-wrapper"
            style={{ overflowX: "auto", marginBottom: "10px" }}
          >
            <table className="text-sm">
              <thead className="tab-head">
                <tr>
                  <th>#</th>
                  <th>Code*</th>
                  <th>Description*</th>
                  <th>Design Group*</th>
                  <th>Item*</th>
                  <th>Picture*</th>
                  <th>Gross Wt*</th>
                  <th>Tol Lower</th>
                  <th>Tol Upper</th>
                  <th style={{ width: "180px" }}>Stone Details</th>
                </tr>
              </thead>
              <tbody className="tab-body">
                <tr>
                  <td>
                    <i className="bi bi-caret-right-fill text-xs md:text-sm"></i>
                  </td>
                  <td>
                    <input
                      name="Design_Code"
                      value={designHeader.Design_Code}
                      onChange={OnChangeHandler}
                      placeholder="Code"
                      maxLength={15}
                      ref={inputRef}
                      className="input-cell text-xs md:text-sm py-1"
                    />
                  </td>
                  <td>
                    <input
                      name="Design_Description"
                      value={designHeader.Design_Description}
                      onChange={OnChangeHandler}
                      placeholder="Description"
                      maxLength={30}
                      className="input-cell text-xs md:text-sm py-1"
                    />
                  </td>
                  <td>
                    <SearchableDropDown
                      options={dropdowndgm}
                      handleChange={(e) =>
                        setDesignHeader((prev) => ({
                          ...prev,
                          Design_Group: e.target.value,
                        }))
                      }
                      selectedVal={designHeader.Design_Group || -1}
                      placeholder={"--Select Group--"}
                      width={"100%"}
                    />
                  </td>
                  <td>
                    <SearchableDropDown
                      options={dropdownitem}
                      handleChange={(e) =>
                        setDesignHeader((prev) => ({
                          ...prev,
                          ID_master: e.target.value,
                        }))
                      }
                      selectedVal={designHeader.ID_master || -1}
                      placeholder={"--Select Item--"}
                      width={"100%"}
                    />
                  </td>
                  <td>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                    />
                  </td>
                  <td>
                    <input
                      name="Gross_Weight"
                      type="number"
                      step="0.001"
                      value={designHeader.Gross_Weight}
                      onChange={OnChangeHandler}
                      placeholder="Gross Wt"
                      className="input-cell text-xs md:text-sm py-1"
                    />
                  </td>
                  <td>
                    <input
                      name="Tolerance_Lower"
                      type="number"
                      value={designHeader.Tolerance_Lower}
                      onChange={OnChangeHandler}
                      placeholder="Tol Lower"
                      className="input-cell text-xs md:text-sm py-1"
                    />
                  </td>
                  <td>
                    <input
                      name="Tolerance_Upper"
                      type="number"
                      value={designHeader.Tolerance_Upper}
                      onChange={OnChangeHandler}
                      placeholder="Tol Upper"
                      className="input-cell text-xs md:text-sm py-1"
                    />
                  </td>
                  <td>
                    <div className="d-flex align-items-center">
                      <input
                        placeholder="Count"
                        className="input-cell"
                        value={designHeader.Details.length}
                        readOnly
                        style={{ width: "50px", marginRight: "5px" }}
                      />
                      <Button
                        variant="secondary"
                        size="sm"
                        onClick={() => setShowModal(true)}
                      >
                        <i
                          className="bi bi-pencil-square"
                          style={{ fontSize: "12px" }}
                        ></i>
                      </Button>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <Button
            variant="success"
            onClick={SaveData}
            disabled={isDisable}
            size="sm"
          >
            {addIsLoading ? "Please wait..." : "Submit"}
          </Button>
        </Col>

        <Col xs={12}>
          <Layout13Table
            isDisable={isDisable}
            setIsDisable={setIsDisable}
            search={searchData}
            setTextDetail={setTextDetail}
            type={"header"}
          />
        </Col>
      </Row>

      {showModal && (
        <DesignDetailsModel
          show={showModal}
          handleClose={() => setShowModal(false)}
          rows={designHeader.Details}
          setRows={handleSaveDetails}
          stoneMOptions={dropdownListStoneM}
          stoneSOptions={dropdownListStoneS}
          sizeOptions={dropdownListSize}
        />
      )}
    </Container>
  );
}

export default DesignMaster;
